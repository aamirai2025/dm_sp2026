---

marp: true
theme: default
html: true
title: discrete mathematics
paginate: true
sanitize: false

---

# Discrete Mathematics 🔢
## Dr. Aamir Alaud Din

### **Topic 2:** Proposition
### **Semester:** Spring 2026

---

# 💡 Learning Outcomes

By the end of this course you will be able to:

- Explain proposition in your own words.
- Explain different types of propositions in your own words.
- Produce truth tables for different types of propositions.
- Present proposition in the form of logic circuits for hardware design.

---

# 🤔 The Why Section

- Computers take actions based on truth value of statements which may be either true or false.
- Sometimes, the truth values of variables are joined together and the outcome of their joint is another variable having a truth value and the computers take actions based on these outcomes.
- What types of joint statements computer may encounter?
- The objective of this topic is to learn how computers take actions based on simple and joint statements.
- We will also learn the pictorial representation of these statements.

---


# Proposition

- A proposition is a declarative sentence (that is, a sentence that declares a fact) that is either true or false, but not both.
### **Example 1**
**a)** Washigton, D. C. is the capital of USA. $\rightarrow$ True
**b)** Toronto is the capital of Canada. $\rightarrow$ False
**c)** $2 + 2 = 4$ $\rightarrow$ True
**d)** $1 + 3 = 3$ $\rightarrow$ False

---

# Proposition

- The following statements are not propositions.

**a)** What time is it? $\rightarrow$ Question
**b)** Read this carefully. $\rightarrow$ Instruction
**c)** $x + 1 = 3$ $\rightarrow$ Not proved
**d)** $y - z = 2x$ $\rightarrow$ Not proved

---

# Proposition

- Propositional variables (or sentential variables) are represented by letters _p_, _q_, _r_, and _s_ _etc._
- It is similar to using variable name for numerical values, for example, $g = 9.8\;m/s^2$ in physics and `g_acc = 9.8` in python programming.
- The truth of proposition is represented by T and represented by F if the proposition is not true or false.
- If a proposition can't be simplified, it is called atomic proposition.
- The area of logic that deals with propositions is called the propositional calculus or propositional logic.

---

# Proposition

- We now turn our attention to methods for producing new propositions from those that we already have. 
- These methods were discussed by the English mathematician George Boole in 1854 in his book The Laws of Thought.
- Many mathematical statements are constructed by combining one or more propositions.
- New propositions, called compound propositions, are formed from existing propositions using logical operators.

---

# Proposition

### **Definition: Negation Proposition**
Let $p$ be a proposition. The negation of $p$, denoted by $\neg p$ (also denoted by $\bar p$), is the statement 
“It is not the case that $p$.”
The proposition $\neg p$ is read “not p.” The truth value of the negation of $p$, $\neg p$, is the opposite of the truth value of $p$.

---

# Proposition

- The negation of the proposition “Michael’s PC runs Linux” is “It is not the case that Michael’s PC runs Linux”.
- The negation of the proposition “Vandana’s smartphone has at least 32 GB of memory” is “It is not the case that Vandana’s smartphone has at least 32 GB of memory”

---

# Proposition

## Truth Table for Negation of a Proposition

| Proposition ($p$)| Negation Proposition ($\neg p$)|
|---|---|
|T | F|
|F | T|


---

# Proposition

### **Definition: Conjunction Proposition**

Let $p$ and $q$ be propositions. The conjunction of $p$ and $q$, denoted by $p \land q$, is the proposition “$p$ and $q$”. The conjunction $p \land q$ is true when both $p$ and $q$ are true and is false otherwise.

|$p$ |$q$|$p \land q$|
|:---|:---|:---|
|T &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;|T&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;|T&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;|
|T|F|F|
|F|T|F|
|F|F|F|

---

### **Definition: Disjunction Proposition**

Let $p$ and $q$ be propositions. The disjunction of $p$ and $q$, denoted by $p \lor q$, is the proposition “$p$ or $q$.” The disjunction $p \lor q$ is false when both $p$ and $q$ are false and is true otherwise.

|$p$ |$q$|$p \lor q$|
|:---|:---|:---|
|T &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;|T&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;|T &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;|
|T|F|T|
|F|T|T|
|F|F|F|

---

# Proposition

### **Definition: Exclusive or Proposition**

Let $p$ and $q$ be propositions. The exclusive or of $p$ and $q$, denoted by $p \oplus q$ (or $p\; XOR \; q$), is the proposition that is true when exactly one of $p$ and $q$ is true and is false otherwise.

|$p$ |$q$|$p \oplus q$|
|:---|:---|:---|
|T &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;|T&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;|F &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;|
|T|F|T|
|F|T|T|
|F|F|F|

---

# Proposition

### **Definition: Conditional Proposition**

Let $p$ and $q$ be propositions. The conditional statement $p \rightarrow q$ is the proposition “if $p$, then $q$.” The conditional statement $p \rightarrow q$ is false when $p$ is true and $q$ is false, and true otherwise. In the conditional statement $p \rightarrow q$, $p$ is called the hypothesis (or antecedent or premise) and $q$ is called the conclusion (or consequence).

|$p$ |$q$|$p \rightarrow q$|
|:---|:---|:---|
|T &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;|T&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;|T &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;|
|T|F|F|
|F|T|T|
|F|F|T|

---

# Proposition

### **Definition: Biconditional Proposition**

Let $p$ and $q$ be propositions. The biconditional statement $p \leftrightarrow q$ is the proposition “$p$ if and only if $q$.” The biconditional statement $p \leftrightarrow q$ is true when $p$ and $q$ have the same truth values, and is false otherwise. Biconditional statements are also called bi-implications.

|$p$ |$q$|$p \leftrightarrow q$|
|:---|:---|:---|
|T &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;|T &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;|T &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;|
|T|F|F|
|F|T|F|
|F|F|T|

---

# Proposition

## Precedence of Logical Operators

|Logical Operator|Precedence|
|:---|:---|
|$\neg$|1|
|$\land$|2|
|$\lor$|3|
|$\rightarrow$|4|
|$\leftrightarrow$|5|

---

# Proposition

## Confusions

- $\neg p \land q$ is not $\neg (p \land q)$ but $(\neg p) \land q$
- $p \lor q \land r$ by default means $p \lor (q \land r)$
- Conditional operator has precedence over biconditional operator, however, in this case, parenthesis must be used.
- $p \lor q \land r$ by default means $p \lor (q \land r)$ but in order to execute $p \lor q$ first, parenthesis should be used like $(p \lor q) \land r$ in which case $\land$ operator has lower precedence than $\lor$.
- Parentheses are used to override default precedence.

---

# Proposition

## Logic and Bit Operations

- Computers don't recognize T and F for true and false propositions.
- They understand 0 and 1 only and are called bits.
- The bits corresponding to T and F are 1 and 0, respectively.

|Truth Value|Bit|
|:---|:---|
|T &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;|1 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;|
|F|0|

---

# Proposition

## Bit Operations

|$x$|$y$|$\neg x$|$x \land y$|$x \lor y$|$x \oplus y$|
|:---|:---|:---|:---|:---|:---|
|0 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;|0 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;|1 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;|0 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;|0 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;|0 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;|
|0|1|1|0|1|1|
|1|0|0|0|1|1|
|1|1|0|1|1|0|

---

# Proposition

### **Example 1:** Bit Operations

$01 \; 1011 \; 0110$
$\underline{11 \; 0001 \; 1101}$
$11 \; 1011 \; 1111$ &nbsp;&nbsp; $\rightarrow$ bitwise OR
$01 \; 0001 \; 0100$ &nbsp;&nbsp; $\rightarrow$ bitwise AND
$10 \; 1010 \; 1011$ &nbsp;&nbsp; $\rightarrow$ bitwise XOR

---

# Boolean Logic

- Propositional logic can be applied to the design of computer hardware.
- This was ﬁrst observed in 1938 by Claude Shannon in his MIT master’s thesis.
- We give a brief introduction to this application here.
- A logic circuit (or digital circuit) receives input signals $p_1$,$p_2$, $\dots$, $p_n$, each a bit [either $0$ (oﬀ) or $1$ (on)], and produces output signals $s_1$, $s_2$, $\dots$ , $s_n$, each a bit.
- In this section we will restrict our attention to logic circuits with a single output signal; in general, digital circuits may have multiple outputs.

---

# Boolean Logic

- Complicated digital circuits can be constructed from three basic circuits, called gates, shown in figure below.

</br>

![figure_1](./images/basic_gates.png)

**Figure 1.** Basic logic gates.

---

# Boolean Logic

- The inverter, or NOT gate, takes an input bit $p$, and produces as output $\neg p$.
- The OR gate takes two input signals $p$ and $q$, each a bit, and produces as output the signal $p \lor q$.
- Finally, the AND gate takes two input signals $p$ and $q$, each a bit, and produces as output the signal $p \land q$.
- We use combinations of these three basic gates to build more complicated circuits, such as that shown in figure below.

---

# Boolean Logic

![figure_2](./images/compound_gates_1.png)

**Figure 2.** A combinatorial circuit.

---

# Boolean Logic

![figure_3](./images/compound_gates_2.png)

**Figure 3.** The logic circuit for $(p \lor \neg r) \land (\neg p \lor (q \lor \neg r))$.

---

# 🎉 Thanks!

Questions?  
