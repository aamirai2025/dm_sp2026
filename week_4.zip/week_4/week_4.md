---

marp: true
theme: default
html: true
title: discrete mathematics
paginate: true
sanitize: false

---

# Discrete Mathematics 🔢
## Dr. Aamir Alaud Din

### **Week 3:** Proposition
### **Semester:** Spring 2026

---

# 🎯 Objectives

By the end of this course you will be able to:

- Explain proposition in your own words.
- Explain different types of propositions in your own words.
- Produce truth tables for different types of propositions.
- Present proposition in the form of logic circuits for hardware design.

---

# Propositional Equivalences

### **Definition: Tautology**

A compound proposition that is always true, no matter what the truth values of the propositional variables that occur in it, is called a tautology.

### **Definition: Contradiction**

A compound proposition that is always false is called a  contradiction.

### **Definition: Contingency**

A compound proposition that is neither a tautology nor a contradiction is called a contingency.

---

# Propositional Equivalences

- We can construct examples of tautologies and contradictions using just one propositional variable.
- Consider the truth tables of $p \lor \neg p$ and $p \land \neg p$, shown in table below.
- Because $p \lor \neg p$ is always true, it is a tautology.
- Because $p \land \neg p$ is always false, it is a contradiction.

|$p$|$\neg p$|$p \lor \neg p$|$p \land \neg p$|
|:---|:---|:---|:---|
|T|F|T|F|
|F|T|T|F|

---

# Propositional Equivalences

## Logical Equivalences

- Compound propositions that have the same truth values in all possible cases are called logically equivalent.
- We can also deﬁne this notion as follows.

### **Definition: Logical Equivalence**

The compound propositions $p$ and $q$ are called logically equivalent if $p \leftrightarrow q$ is a tautology. The notation $p \equiv q$ denotes that $p$ and $q$ are logically equivalent.

---

# Propositional Equivalences

- The symbol $\equiv$ is not a logical connective, and $p \equiv q$ is not a compound proposition but rather is the statement that $p \iff q$ is a tautology.
- The symbol $\iff$ is sometimes used instead of $\equiv$ to denote logical equivalence.
- One way to determine whether two compound propositions are equivalent is to use a truth table.
- In particular, the compound propositions $p$ and $q$ are equivalent if and only if the columns giving their truth values agree.

---

# Propositional Equivalences

- This logical equivalence is one of the two **De Morgan laws**, shown in table below, named after the English mathematician Augustus De Morgan, of the mid-nineteenth century.
- Example below illustrates this method to establish an extremely
important and useful logical equivalence, namely, that of $\neg (p \lor q)$ with $\neg p \land \neg q$.

|**De Morgan's Laws**|
|:---:|
|$\neg (p \land q) \equiv \neg p \lor \neg q$|
|$\neg (p \lor q) \equiv \neg p \land \neg q$|

---

# Propositional Equivalences

### **Example** 

Show that $\neg (p \lor q)$ and $\neg p \land \neg q$ are logically equivalent.

### **Solution**

|$p$|$q$|$p \lor q$|$\neg (p \lor q)$|$\neg p$|$\neg q$|$\neg p \land \neg q$|
|:---|:---|:---|:---|:---|:---|:---|
|T|T|T|F|F|F|F|
|T|F|T|F|F|T|F|
|F|T|T|F|T|F|F|
|F|F|F|T|T|T|T|

---

# Propositional Equivalences

### **Example**

Show that $p \rightarrow q$ and $\neg p \lor q$ are logically equivalent. (This is known as the **conditional disjunction equivalence**).

### **Solution**

|$p$|$q$|$\neg p$|$\neg p \lor q$|$p \rightarrow q$|
|:---|:---|:---|:---|:---|
|T|T|F|T|T|
|T|F|F|F|F|
|F|T|T|T|T|
|F|F|T|T|T|

---

# Propositional Equivalences

### **Example**

Show that $p \lor (q \land r)$ and $(p \lor q) \land (p \lor r)$ are logically equivalent. This is the distributive law of disjunction over conjunction.

### **Solution**

|$p$|$q$|$r$|$q \land r$|$p \lor (q \land r)$|$p \lor q$|$p \lor r$|$(p \lor q) \land (p \lor r)$|
|:---|:---|:---|:---|:---|:---|:---|:---|
|T|T|T|T|T|T|T|T|
|T|T|F|F|T|T|T|T|
|T|F|T|F|T|T|T|T|
|T|F|F|F|T|T|T|T|


---

# Propositional Equivalences

### **Solution Continued...**

|$p$|$q$|$r$|$q \land r$|$p \lor (q \land r)$|$p \lor q$|$p \lor r$|$(p \lor q) \land (p \lor r)$|
|:---|:---|:---|:---|:---|:---|:---|:---|
|F|T|T|T|T|T|T|T|
|F|T|F|F|F|T|F|F|
|F|F|T|F|F|F|T|F|
|F|F|F|F|F|F|F|F|

---

# Propositional Equivalences

### **Homework No. 1**

Prove the logical equivalences in table 6, page 29.

---

# Sets

## Introduction

- Sets are used to group objects together. Often, but not always, the objects in a set have similar properties.
- For instance, all the students who are currently enrolled in your school make up a set.
- Likewise, all the students currently taking a course in discrete mathematics at any school make up a set.

---

# Sets

- In addition, those students enrolled in your school who are taking a course in discrete mathematics form a set that can be obtained by taking the elements common to the ﬁrst two collections.
- The language of sets is a means to study such collections in an organized fashion.
- We now provide a deﬁnition of a set.
- This deﬁnition is an intuitive deﬁnition, which is not part of a formal theory of sets.

---

# Sets

### **Definition: Set**

A set is an unordered collection of distinct objects, called elements or members of the set. A set is said to contain its elements. We write $a \in A$ to denote that $a$ is an element of the set $A$. The notation $a \notin A$ denotes that a is not an element of the set $A$.

- It is common for sets to be denoted using uppercase letters.
- Lowercase letters are usually used to denote elements of sets.

---

# Sets

- There are several ways to describe a set.
- One way is to list all the members of a set, when this is possible.
- We use a notation where all members of the set are listed between braces.
- For example, the notation $\{a, b, c, d\}$ represents the set with the four elements $a, b, c,$ and $d$.
- This way of describing a set is known as the **roster method**.

---

# Sets

### **Example**

The set $V$ of all vowels in the English alphabet can be written as $V = \{a, e, i, o, u\}$.

### **Example**

The set $O$ of odd positive integers less than $10$ can be expressed by $O = \{1, 3, 5, 7, 9\}$.

---

# Sets

- Although sets are usually used to group together elements with common properties, there is nothing that prevents a set from having seemingly unrelated elements.
- For instance, $\{a, 2, Fred, New Jersey\}$ is the set containing the four elements $a, 2, Fred,$ and $New\;Jersey$.
- Sometimes the roster method is used to describe a set without listing all its members.
- Some members of the set are listed, and then ellipses $(\dots)$ are used when the general pattern of the elements is obvious.

---

# Sets

### **Example**

The set of positive integers less than $100$ can be denoted by $\{1, 2, 3, … , 99\}$.

- Another way to describe a set is to use set builder notation.
- We characterize all those elements in the set by stating the property or properties they must have to be members.
- The general form of this notation is $\{x \mid x \; has \; property \; P\}$ and is read “the set of all $x$ such that $x$ has property $P$.”

---

# Sets

- For instance, the set $O$ of all odd positive integers less than $10$ can be written as

$$
O = \{x \mid x \; is \; an \; odd \; positive \; integer \; less \; than \; 10\}
$$

or, specifying the universe as the set of positive integers, as

$$
O = \{x \in \mathbf{Z^+} \mid x \; is \; odd \; and \; x < 10\}
$$

- We often use this type of notation to describe sets when it is impossible to list all the elements of the set.

---

# Sets

- For instance, the set Q+ of all positive rational numbers can be written as

$$
\mathbf{Q^+} = \left\{ x \in \mathbf{R} \mid x = \frac{p}{q} \; for \; some \; positive \; integers \; p \; and \; q \right\}
$$

- These sets, each denoted using a boldface letter, play an important role in discrete mathematics:

$$
\mathbf{N} = \{0, 1, 2, 3, \dots \}, \text{the set of all natural numbers}
$$

$$
\mathbf{Z} = \{\dots, -2, -1, 0, 1, 2, \dots\}, \text{the set of all integers}
$$

$$
\mathbf{Z^+} = \{1, 2, 3, \dots \}, \text{the set of all positive integers}
$$

---

# Sets

$$
\mathbf{Q} = \left \{ \frac{p}{q} \mid p \in \mathbf{Z}, q \in \mathbf{Z}, \text{ and } q \ne 0 \right \}, \text{the set of all rational numbers}
$$

$$
\mathbf{R}, \text{the set of all real numbers}
$$

$$
\mathbf{R^+}, \text{the set of all positive real numbers}
$$

$$
\mathbf{C}, \text{the set of all complex numbers}
$$

---

# Sets

- Among the sets studied in calculus and other subjects are intervals, sets of all the real numbers between two numbers $a$ and $b$, with or without $a$ and $b$.
- If $a$ and $b$ are real numbers with $a \le b$, we denote these intervals by

$$
[a, b] = \{x \mid a \le x \le b \} \\
$$

$$
[a, b) = \{x \mid a \le x \lt b \}
$$

$$
(a, b] = \{x \mid a \lt x \le b \}
$$

$$
(a, b) = \{x \mid a \lt x \lt b \}
$$

- Sets can have other sets as members _e.g.,_ $\{\mathbf{R}, \mathbf{Q}, \mathbf{N}, \mathbf{Z}\}$

---

# Sets

- Because many mathematical statements assert that two diﬀerently speciﬁed collections of objects are really the same set, we need to understand what it means for two sets to be equal.

### **Definition: Equal Sets**

Two sets are equal if and only if they have the same elements. Therefore, if $A$ and $B$ are sets, then $A$ and $B$ are equal if and only if $\forall \; x \; (x \in A \leftrightarrow x \in B)$. We write $A = B$ if $A$ and $B$ are equal sets.

---

# Sets

- The sets $\{1, 3, 5\}$ and $\{3, 5, 1\}$ are equal, because they have the same elements.
- Note that the order in which the elements of a set are listed does not matter.
- Note also that it does not matter if an element of a set is listed more than once, so $\{1, 3, 3, 3, 5, 5, 5, 5\}$ is the same as the set $\{1, 3, 5\}$ because they have the same elements.

---

# Sets

- There is a special set that has no elements. 
- This set is called the empty set, or null set, and is denoted by $\phi$.
- The empty set can also be denoted by $\{\}$ (that is, we represent
the empty set with a pair of braces that encloses all the elements in this set).
- Often, a set of elements with certain properties turns out to be the null set.
- For instance, the set of all positive integers that are greater than their squares is the null set.

---

# Sets

- A set with one element is called a singleton set.
- A common error is to confuse the empty set $\phi$ with the set $\{\phi\}$, which is a singleton set.
- The single element of the set $\{\phi\}$ is the empty set itself!
- A useful analogy for remembering this diﬀerence is to think of folders in a computer ﬁle system.
- The empty set can be thought of as an empty folder and the set consisting of just the empty set can be thought of as a folder with exactly one folder inside, namely, the empty folder.

---

# Sets: Venn Diagrams

- Sets can be represented graphically using Venn diagrams, named after the English mathematician John Venn, who introduced their use in 1881.
- In Venn diagrams the universal set $U$, which contains all the objects under consideration, is represented by a rectangle.
- Inside this rectangle, circles or other geometrical ﬁgures are used to represent sets.
- Sometimes points are used to represent the particular elements of the set.
- Venn diagrams are often used to indicate the relationships between
sets.

---

# Sets: Venn Diagrams

### **Example**

Draw a Venn diagram that represents $V$, the set of vowels in the English alphabet.

### **Solution**

We draw a rectangle to indicate the universal set $U$, which is the set of the 26 letters of the English alphabet. Inside this rectangle we draw a circle to represent $V$. Inside this circle we indicate the elements of $V$ with points.

---

# Sets: Venn Diagrams

![width:30em](./images/venn_english_alphabets.png)

---

# Sets: Subset

- It is common to encounter situations where the elements of one set are also the elements of a second set.
- We now introduce some terminology and notation to express such relationships between sets.

### **Definition: Subset**

The set $A$ is a subset of $B$, and $B$ is a superset of $A$, if and only if every element of $A$ is also an element of $B$. We use the notation $A \subseteq B$ to indicate that $A$ is a subset of the set $B$. If, instead, we want to stress that $B$ is a superset of $A$, we use the equivalent notation $B \supseteq A$. So, $A \subseteq B$ and $B \supseteq A$ are equivalent statements.

---

# Sets: Subset

- We see that $A \subseteq B$ if and only if the quantiﬁcation

$$
\forall \; x \; (x \in A \rightarrow x \in B)
$$

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; is true.

- Note that to show that $A$ is not a subset of $B$ we need only ﬁnd one element $x \in A$ with $x \notin B$.
- Such an $x$ is a counter example to the claim that $x \in A$ implies $x \in B$.

---

# Sets: Subset

- We have these useful rules for determining whether one set is a subset of another:

**Showing that $\mathbf{A}$ is a Subset of $\mathbf{B}$:** To show that $A \subseteq B$, show that if $x$ belongs to $A$ then $x$ also belongs to $B$.

**Showing that $\mathbf{A}$ is Not a Subset of $\mathbf{B}$:** To show that $A \nsubseteq B$, ﬁnd a single $x \in A$ such that $x \notin B$.

- The venn diagram of a subset is shown below.

---

# Sets: Subset

![width:30em](./images/venn_subset.png)

---

# Sets: Subset

**Showing Two Sets are Equal:** To show that two sets $A$ and $B$ are equal, show that $A \subseteq B$ and $B \subseteq A$.

- Sets may have other sets as members.
- For instance, we have the sets

$$
A = \{\phi, \{a\}, \{b\}, \{a, b\}\}
$$

$$
B = \{x \mid x \text{ is a subset of the set }\{a, b\}\}
$$

- Note that these two sets are equal, that is, $A = B$.
- Also note that $\{a\} \in A$, but $a \notin A$.

---

# Set: Size of Set

- Sets are used extensively in counting problems, and for such applications we need to discuss the sizes of sets.

### **Definition: Size of Set**

Let $S$ be a set. If there are exactly $n$ distinct elements in $S$ where $n$ is a nonnegative integer, we say that $S$ is a ﬁnite set and that $n$ is the cardinality of $S$. The cardinality of $S$ is denoted by $|S|$.

---

# Sets: Size of Set

### **Examples**

- Let $A$ be the set of odd positive integers less than $10$. Then $|A| = 5$.
- Let $S$ be the set of letters in the English alphabet. Then $|S| = 26$.
- Because the null set has no elements, it follows that $|\phi| = 0$.

### **Definition: Infinite Set**

A set is said to be inﬁnite if it is not ﬁnite.
- The set of positive integers is inﬁnite.

---

# Sets: Power Sets

- Many problems involve testing all combinations of elements of a set to see if they satisfy some property.
- To consider all such combinations of elements of a set $S$, we build a new set that has as its members all the subsets of $S$.

### **Definition: Power Set**

Given a set $S$, the power set of $S$ is the set of all subsets of the set $S$. The power set of $S$ is denoted by $P(S)$.

---

# Sets: Power Sets

### **Example**
What is the power set of the set $\{0, 1, 2\}$?

### **Solution**
$P(S) = \{\phi, \{0\}, \{1\}, \{2\}, \{0, 1\}, \{0, 2\}, \{1, 2\}, \{0, 1, 2\}\}$

### **Note:**
Empty set and the set itseld are elements of power set.

---

# Sets: Cartesian Products

The order of elements in a collection is often important. Because sets are unordered, a different structure is needed to represent ordered collections. This is provided by ***ordered n-tuples***.

### **Definition:** ***Ordered n-tuple***

The ***ordered n-tuple*** $(a_1 , a_2 , \dots , a_n)$ is the ordered collection that has $a_1$ as its first element, $a_2$ as its second element, ... , and $a_n$ as its _n_th element.

- We say that two ***ordered n-tuples*** are equal if and only if each corresponding pair of their elements is equal.

---

# Sets: Cartesian Products

- In other words, $(a_1 , a_2, \dots , a_n ) = (b_1, b_2 , \dots , b_n)$ if and only if $a_i = b_i$ , for $i = 1, 2, \dots , n$.
- In particular, ***ordered 2-tuples*** are called ordered pairs.
- The ordered pairs $(a, b)$ and $(c, d)$ are equal if and only if $a = c$ and $b = d$.
- Note that $(a, b)$ and $(b, a)$ are not equal unless $a = b$.
- Many of the discrete structures we will study in later chapters are based on the notion of the Cartesian product of sets (named after René Descartes).
- We first define the Cartesian product of two sets.

---

# Sets: Cartesian Products

### **Definition: Cartesian Product**

Let $A$ and $B$ be sets. The Cartesian product of $A$ and $B$, denoted by $A \times B$, is the set of all ordered pairs $(a, b)$, where $a \in A$ and $b \in B$. Hence,

$$
A \times B = \{(a, b) ∣ a \in A ∧ b \in B\}.
$$

### **Example**

What is the Cartesian product of $A = \{1, 2\}$ and $B = \{a, b, c\}$?

### **Solution**

$$
A \times B = \{(1, a), (1, b), (1, c), (2, a), (2, b), (2, c)\}
$$

---

# Sets: Cartesian Products

### **Definition: Cartesian Product of $\mathbf{n}$ Sets**

The Cartesian product of the sets $A_1 , A_2 , \dots , A_n$, denoted by $A_1 \times A_2 \times \dots \times A_n$ , is the set of ***ordered n-tuples*** $(a_1 , a_2 , \dots , a_n)$, where $a_i$ belongs to $A_i$ for $i = 1, 2, \dots , n$. In other words,

$$
A_1 \times A_2 \times \dots \times A_n = \{(a_1 , a_2 , \dots , a_n) ∣ a_i \in A_i \text{ for } i = 1, 2, \dots , n \}.
$$

### **Example**

What is the Cartesian product of $A = \{0, 1\}$ and $B = \{1, 2\}$, and $C = \{0, 1, 2\}$?

### **Solution**

Do yourself.

---

# 🎉 Thanks!

Questions?  
