### Introduction to Boolean Algebra: Foundations (Approximately 20-25 Minutes)

Boolean algebra is a branch of mathematics that deals with variables that can only take two values: true or false, often represented as 1 (true) or 0 (false). It forms the foundation of digital logic, computer science, electrical engineering, and even philosophy of logic. Let's start with the foundations to understand why and how it exists.

#### Historical Foundations
Boolean algebra was developed by George Boole in the mid-19th century (around 1847-1854) in his works like "The Mathematical Analysis of Logic" and "The Laws of Thought." Boole aimed to create a mathematical system for reasoning about logic, similar to how algebra handles numbers. He was influenced by Aristotelian logic, which dealt with propositions like "all men are mortal," but Boole formalized it into equations.

- **Example**: In traditional logic, "All A is B" might be thought of qualitatively. Boole represented it as A = A * B (where * means intersection or AND), assuming A and B are sets or classes. This shifted logic from words to symbols, making it computable.

Claude Shannon later (in 1937) applied Boolean algebra to electrical circuits, showing that switches (on/off) could represent Boolean values. This paved the way for modern computers.

- **Example Application**: In a simple light switch circuit, if Switch A and Switch B must both be on for the light to turn on, that's an AND operation. If either can turn it on, it's OR.

#### Connection to Set Theory
Boolean algebra is isomorphic (structurally identical) to set theory operations on subsets. For a universal set U:

- Union (∪) corresponds to OR (+ or ∨).
- Intersection (∩) corresponds to AND (⋅ or ∧).
- Complement (') corresponds to NOT (¬ or overbar).

- **Example**: Let U = {1,2,3,4}, A = {1,2}, B = {2,3}.
  - A ∪ B = {1,2,3} (like A OR B).
  - A ∩ B = {2} (like A AND B).
  - A' = {3,4} (NOT A).

This shows Boolean algebra isn't just abstract—it's mirrored in real-world collections.

#### Connection to Propositional Logic
In logic, propositions are statements that are true or false. Boolean algebra formalizes operations on them.

- **Example**: Let P = "It is raining," Q = "I carry an umbrella."
  - P AND Q: "It is raining and I carry an umbrella."
  - P OR Q: "It is raining or I carry an umbrella."
  - NOT P: "It is not raining."

Truth values: If P is true (1) and Q is false (0), then P AND Q is false (0).

#### Why Two Values? (Binary Nature)
The binary system simplifies decision-making. In probability, it relates to events happening (1) or not (0). In computing, bits are 0 or 1.

- **Example**: A coin flip: Heads (1) or Tails (0). Combining flips: Both heads (AND), at least one heads (OR).

Spend time here reflecting: Why not three values? (There are extensions like fuzzy logic, but Boolean is binary for certainty.)

### Basic Operations in Boolean Algebra (Approximately 30-35 Minutes)

Now, let's dive into the basics. Boolean algebra has three primary operations: AND (conjunction), OR (disjunction), and NOT (negation). Variables are usually A, B, C, etc., and can be 0 or 1.

#### 1. NOT Operation (Negation, Complement)
- **Definition**: Flips the value. NOT A (denoted ¬A, A', or \bar{A}) is 1 if A=0, and 0 if A=1.
- **Truth Table** (a table showing all possibilities):
  | A | NOT A |
  |---|-------|
  | 0 | 1     |
  | 1 | 0     |

- **Example 1**: In a security system, A = "Door is locked" (1=locked). NOT A = "Door is unlocked." If door is locked (1), alarm off; if unlocked (0 for locked? Wait, redefine: Let A=1 mean unlocked, NOT A=1 means locked.

- **Example 2**: In programming, if user_logged_in = False (0), then NOT user_logged_in = True (show login screen).

- **Example 3**: Set theory: If A is "even numbers" in {1,2,3,4}, A={2,4}, NOT A={1,3} (odds).

Practice: What is NOT (NOT A)? It's A again (involution). Truth table confirms: Double negation returns original.

#### 2. AND Operation (Conjunction, Multiplication)
- **Definition**: A AND B (A ∧ B, A ⋅ B, or AB) is 1 only if both A=1 and B=1; else 0. Like multiplication (1*1=1, others 0).
- **Truth Table**:
  | A | B | A AND B |
  |---|---|---------|
  | 0 | 0 | 0       |
  | 0 | 1 | 0       |
  | 1 | 0 | 0       |
  | 1 | 1 | 1       |

- **Example 1**: Access control: A="Has ID" (1=yes), B="Knows password" (1=yes). A AND B=1 means grant access only if both true.

- **Example 2**: Logic puzzle: "You can enter if you're over 18 AND have a ticket." If age<18 (0) or no ticket (0), entry=0.

- **Example 3**: Circuit: Two switches in series—current flows only if both closed (1).

- **Example 4**: Multiple variables: A AND B AND C. Truth table expands to 8 rows (2^3). It's 1 only in row where all are 1.

Common mistake: AND is strict—most cases are 0.

#### 3. OR Operation (Disjunction, Addition)
- **Definition**: A OR B (A ∨ B or A + B) is 1 if at least one is 1; 0 only if both 0. Like addition but capped (1+1=1, not 2).
- **Truth Table**:
  | A | B | A OR B |
  |---|---|--------|
  | 0 | 0 | 0      |
  | 0 | 1 | 1      |
  | 1 | 0 | 1      |
  | 1 | 1 | 1      |

- **Example 1**: Alarm system: A="Motion detected," B="Door opened." A OR B=1 triggers alarm if either happens.

- **Example 2**: Eligibility: "Qualify if GPA>3.0 OR recommendation letter." If GPA low (0) but letter (1), still qualify (1).

- **Example 3**: Circuit: Two switches in parallel—current flows if at least one closed.

- **Example 4**: Inclusive vs. Exclusive: Boolean OR is inclusive (1+1=1 allowed). For exclusive (XOR), it's (A AND NOT B) OR (NOT A AND B). Truth table for XOR:
  | A | B | A XOR B |
  |---|---|---------|
  | 0 | 0 | 0       |
  | 0 | 1 | 1       |
  | 1 | 0 | 1       |
  | 1 | 1 | 0       |
  Example: Light toggle—flips only if inputs differ.

Note: OR is lenient—most cases are 1.

#### Derived Operations (NAND, NOR, etc.)
- NAND: NOT (A AND B). 0 only if both 1.
- NOR: NOT (A OR B). 1 only if both 0.
- **Example**: NAND gates are universal—can build any logic from them. E.g., NOT A = A NAND A.

Truth table for NAND:
  | A | B | A NAND B |
  |---|---|----------|
  | 0 | 0 | 1        |
  | 0 | 1 | 1        |
  | 1 | 0 | 1        |
  | 1 | 1 | 0        |

### Laws and Theorems of Boolean Algebra (Approximately 45-50 Minutes)

Boolean algebra follows axioms (basic truths) and theorems (derived rules). These help simplify expressions, like in circuit design to reduce gates.

#### Axioms (Postulates)
These are assumed true without proof.

1. **Identity Laws**:
   - A + 0 = A (OR with false is itself).
   - A ⋅ 1 = A (AND with true is itself).
   - **Example**: In search: Query OR "nothing" = Query. "User is admin" AND True = "User is admin."

2. **Null (or Dominance) Laws**:
   - A + 1 = 1 (OR with true is true).
   - A ⋅ 0 = 0 (AND with false is false).
   - **Example**: "Has access" OR True = Always true (bypass). "Verified" AND False = Never verified.

3. **Complement Laws**:
   - A + A' = 1 (Something or its opposite is always true).
   - A ⋅ A' = 0 (Something and its opposite is false).
   - **Example**: "Raining" OR "Not raining" = Always true (tautology). "Even" AND "Odd" = Impossible (contradiction).

4. **Idempotent Laws**:
   - A + A = A.
   - A ⋅ A = A.
   - **Example**: "Apple OR Apple" = "Apple." Duplicate conditions don't change.

5. **Involution Law**:
   - (A')' = A.
   - **Example**: NOT (NOT "Happy") = "Happy."

#### Theorems (Derived)
These are proven from axioms.

1. **Commutative Laws**:
   - A + B = B + A.
   - A ⋅ B = B ⋅ A.
   - **Example**: "Cat OR Dog" = "Dog OR Cat." Order doesn't matter in logic gates.

2. **Associative Laws**:
   - (A + B) + C = A + (B + C).
   - (A ⋅ B) ⋅ C = A ⋅ (B ⋅ C).
   - **Example**: Groupings: (Rain AND Wind) AND Cold = Rain AND (Wind AND Cold). Simplifies complex expressions.

3. **Distributive Laws** (Key for Simplification):
   - A ⋅ (B + C) = (A ⋅ B) + (A ⋅ C).
   - A + (B ⋅ C) = (A + B) ⋅ (A + C).
   - **Example 1**: Factor out: Admin AND (Read OR Write) = (Admin AND Read) OR (Admin AND Write). Like permissions.
   - **Example 2**: Second form: Error + (Critical AND Logged) = (Error + Critical) ⋅ (Error + Logged). Useful in fault analysis.
   - Contrast with arithmetic: x*(y+z)=x*y + x*z (same), but x + y*z ≠ (x+y)*(x+z).

4. **Absorption Laws**:
   - A + (A ⋅ B) = A.
   - A ⋅ (A + B) = A.
   - **Example**: "Fruit" OR ("Fruit" AND "Apple") = "Fruit" (absorbs the specific). Redundant terms removed.

5. **De Morgan's Theorems** (Very Important for Negation):
   - (A + B)' = A' ⋅ B'.
   - (A ⋅ B)' = A' + B'.
   - **Example 1**: NOT (A OR B) = (NOT A) AND (NOT B). "Not (raining or snowing)" = "Not raining and not snowing."
   - **Example 2**: NOT (A AND B) = (NOT A) OR (NOT B). "Not both true" = "At least one false."
   - **Example 3**: Simplify (A' + B')' = A'' ⋅ B'' = A ⋅ B (using involution).
   - Application: Convert AND to OR gates with inverters in circuits.

6. **Consensus Theorem** (Advanced Simplification):
   - (A ⋅ B) + (A' ⋅ C) + (B ⋅ C) = (A ⋅ B) + (A' ⋅ C).
   - **Example**: Removes redundant (B ⋅ C) if other terms cover it.

#### Simplification Examples (Practice 10-15 Minutes)
Use laws to simplify expressions. This is like factoring in algebra.

- **Example 1**: Simplify A ⋅ B + A ⋅ B' = A ⋅ (B + B') = A ⋅ 1 = A (distributive, complement).

- **Example 2**: A + A' ⋅ B = (A + A') ⋅ (A + B) = 1 ⋅ (A + B) = A + B (distributive variant).

- **Example 3**: (A + B') ⋅ (A' + B) = A⋅A' + A⋅B + B'⋅A' + B'⋅B = 0 + A B + A' B' + 0 = A B + A' B' (expand, then complements).

- **Example 4**: Using De Morgan: NOT (A OR (B AND C)) = A' AND (B AND C)' = A' AND (B' OR C').

Truth tables verify: Build one for original and simplified— they match.

### Applications and Wrap-Up (Approximately 20-25 Minutes)

#### Real-World Applications
- **Digital Circuits**: Gates (AND, OR, NOT) build adders, multiplexers. E.g., Full adder: Sum = A XOR B XOR Carry_in.
- **Programming**: If statements: if (A && B) {} (AND), || (OR).
- **Databases**: SQL WHERE clauses: WHERE age > 18 AND country = 'US'.
- **AI/Search**: Boolean search: "cat AND dog NOT bird".

- **Example Circuit**: Half-adder: S = A XOR B = (A B') + (A' B), Carry = A B.

#### Common Pitfalls
- Confusing OR with XOR (OR allows both true).
- Forgetting precedence: NOT > AND > OR (use parentheses).
- Overcomplicating: Always simplify using laws.

#### Exercises (Self-Paced)
1. Build truth table for (A AND B) OR (NOT C).
2. Simplify: A' B + A B + A B'.
3. Prove De Morgan using truth tables.

This covers foundations and basics in depth. Total time: ~2 hours if reading aloud with pauses for examples. For deeper dive, explore Karnaugh maps next!
