---

marp: true
theme: default
html: true
title: discrete mathematics
paginate: true
sanitize: false

---

# Discrete Mathematics 🔢
## Dr. Aamir Alaud Din

### **Week 3:** Proposition
### **Semester:** Spring 2026

---

# 🎯 Objectives

By the end of this course you will be able to:

- Explain proposition in your own words.
- Explain different types of propositions in your own words.
- Produce truth tables for different types of propositions.
- Present proposition in the form of logic circuits for hardware design.

---

# Propositional Equivalences

### **Definition: Tautology**

A compound proposition that is always true, no matter what the truth values of the propositional variables that occur in it, is called a tautology.

### **Definition: Contradiction**

A compound proposition that is always false is called a  contradiction.

### **Definition: Contingency**

A compound proposition that is neither a tautology nor a contradiction is called a contingency.

---

# Propositional Equivalences

- We can construct examples of tautologies and contradictions using just one propositional variable.
- Consider the truth tables of $p \lor \neg p$ and $p \land \neg p$, shown in table below.
- Because $p \lor \neg p$ is always true, it is a tautology.
- Because $p \land \neg p$ is always false, it is a contradiction.

|$p$|$\neg p$|$p \lor \neg p$|$p \land \neg p$|
|:---|:---|:---|:---|
|T|F|T|F|
|F|T|T|F|

---

# Propositional Equivalences

## Logical Equivalences

- Compound propositions that have the same truth values in all possible cases are called logically equivalent.
- We can also deﬁne this notion as follows.

### **Definition: Logical Equivalence**

The compound propositions $p$ and $q$ are called logically equivalent if $p \leftrightarrow q$ is a tautology. The notation $p \equiv q$ denotes that $p$ and $q$ are logically equivalent.

---

# Propositional Equivalences

- The symbol $\equiv$ is not a logical connective, and $p \equiv q$ is not a compound proposition but rather is the statement that $p \iff q$ is a tautology.
- The symbol $\iff$ is sometimes used instead of $\equiv$ to denote logical equivalence.
- One way to determine whether two compound propositions are equivalent is to use a truth table.
- In particular, the compound propositions $p$ and $q$ are equivalent if and only if the columns giving their truth values agree.

---

# Propositional Equivalences

- This logical equivalence is one of the two **De Morgan laws**, shown in table below, named after the English mathematician Augustus De Morgan, of the mid-nineteenth century.
- Example below illustrates this method to establish an extremely
important and useful logical equivalence, namely, that of $\neg (p \lor q)$ with $\neg p \land \neg q$.

|**De Morgan's Laws**|
|:---:|
|$\neg (p \land q) \equiv \neg p \lor \neg q$|
|$\neg (p \lor q) \equiv \neg p \land \neg q$|

---

# Propositional Equivalences

### **Example** 

Show that $\neg (p \lor q)$ and $\neg p \land \neg q$ are logically equivalent.

### **Solution**

|$p$|$q$|$p \lor q$|$\neg (p \lor q)$|$\neg p$|$\neg q$|$\neg p \land \neg q$|
|:---|:---|:---|:---|:---|:---|:---|
|T|T|T|F|F|F|F|
|T|F|T|F|F|T|F|
|F|T|T|F|T|F|F|
|F|F|F|T|T|T|T|

---

# Propositional Equivalences

### **Example**

Show that $p \rightarrow q$ and $\neg p \lor q$ are logically equivalent. (This is known as the **conditional disjunction equivalence**).

### **Solution**

|$p$|$q$|$\neg p$|$\neg p \lor q$|$p \rightarrow q$|
|:---|:---|:---|:---|:---|
|T|T|F|T|T|
|T|F|F|F|F|
|F|T|T|T|T|
|F|F|T|T|T|

---

# Propositional Equivalences

### **Example**

Show that $p \lor (q \land r)$ and $(p \lor q) \land (p \lor r)$ are logically equivalent. This is the distributive law of disjunction over conjunction.

### **Solution**

|$p$|$q$|$r$|$q \land r$|$p \lor (q \land r)$|$p \lor q$|$p \lor r$|$(p \lor q) \land (p \lor r)$|
|:---|:---|:---|:---|:---|:---|:---|:---|
|T|T|T|T|T|T|T|T|
|T|T|F|F|T|T|T|T|
|T|F|T|F|T|T|T|T|
|T|F|F|F|T|T|T|T|


---

# Propositional Equivalences

### **Solution Continued...**

|$p$|$q$|$r$|$q \land r$|$p \lor (q \land r)$|$p \lor q$|$p \lor r$|$(p \lor q) \land (p \lor r)$|
|:---|:---|:---|:---|:---|:---|:---|:---|
|F|T|T|T|T|T|T|T|
|F|T|F|F|F|T|F|F|
|F|F|T|F|F|F|T|F|
|F|F|F|F|F|F|F|F|

---

# Propositional Equivalences

### **Homework No. 1**

Prove the logical equivalences in table 6, page 29.

---

# 🎉 Thanks!

Questions?  
